﻿using System;
namespace ConsoleApp1
{
    class Program
    {
        public static Scanner scanner = new Scanner(147, 46);

        static void Main(string[] args)
        {
            scanner.addFinal(9);
            scanner.addFinal(15);
            scanner.addFinal(17);
            scanner.addFinal(21);
            scanner.addFinal(24);
            scanner.addFinal(29);
            scanner.addFinal(32);
            scanner.addFinal(37);
            scanner.addFinal(38);
            scanner.addFinal(39);
            scanner.addFinal(43);
            scanner.addFinal(50);
            scanner.addFinal(63);
            scanner.addFinal(80);
            scanner.addFinal(88);
            scanner.addFinal(90);
            scanner.addFinal(94);
            scanner.addFinal(105);
            scanner.addFinal(112);
            scanner.addFinal(114);
            scanner.addFinal(115);
            scanner.addFinal(116);
            scanner.addFinal(117);
            scanner.addFinal(118);
            scanner.addFinal(120);
            scanner.addFinal(122);
            scanner.addFinal(123);
            scanner.addFinal(125);
            scanner.addFinal(126);
            scanner.addFinal(127);
            scanner.addFinal(124);
            scanner.addFinal(128);
            scanner.addFinal(129);
            scanner.addFinal(131);
            scanner.addFinal(132);
            scanner.addFinal(133);
            scanner.addFinal(134);
            scanner.addFinal(135);
            scanner.addFinal(136);
            scanner.addFinal(137);
            scanner.addFinal(138);
            scanner.addFinal(139);
            scanner.addFinal(144);
            scanner.addFinal(145);
            scanner.addFinal(146);
            scanner.addFinal(147);
            scanner.addTrans(1, 'r', 64);
            scanner.addTrans(1, 'e', 18);
            scanner.addTrans(1, 'p', 106);
            scanner.addTrans(1, 'l', 44);
            scanner.addTrans(1, 'i', 16);
            scanner.addTrans(1, 't', 51);
            scanner.addTrans(1, 'c', 2);
            scanner.addTrans(1, 'u', 140);
            scanner.addTrans(1, 'n', 40);
            scanner.addTrans(1, 'd', 10);
            scanner.addTrans(1, 's', 25);
            scanner.addTrans(1, '+', 115);
            scanner.addTrans(1, '-', 116);
            scanner.addTrans(1, '*', 117);
            scanner.addTrans(1, '/', 118);
            scanner.addTrans(1, '&', 119);
            scanner.addTrans(1, '|', 121);
            scanner.addTrans(1, '~', 123);
            scanner.addTrans(1, '=', 124);
            scanner.addTrans(1, '<', 126);
            scanner.addTrans(1, '>', 128);
            scanner.addTrans(1, '!', 130);
            scanner.addTrans(1, '.', 132);
            scanner.addTrans(1, '{', 133);
            scanner.addTrans(1, '}', 134);
            scanner.addTrans(1, '[', 135);
            scanner.addTrans(1, ']', 136);
            scanner.addTrans(1, '"', 138);
            scanner.addTrans(1, '\'', 139);
            scanner.addTrans(1, '0', 137);
            scanner.addTrans(1, '1', 137);
            scanner.addTrans(1, '2', 137);
            scanner.addTrans(1, '3', 137);
            scanner.addTrans(1, '4', 137);
            scanner.addTrans(1, '5', 137);
            scanner.addTrans(1, '6', 137);
            scanner.addTrans(1, '7', 137);
            scanner.addTrans(1, '8', 137);
            scanner.addTrans(1, '9', 137);
            scanner.addTrans(2, 'l', 30);
            scanner.addTrans(2, 'h', 91);
            scanner.addTrans(2, 'o', 70);
            scanner.addTrans(2, 'a', 3);
            scanner.addTrans(3, 't', 4);
            scanner.addTrans(4, 'e', 5);
            scanner.addTrans(5, 'g', 6);
            scanner.addTrans(6, 'o', 7);
            scanner.addTrans(7, 'r', 8);
            scanner.addTrans(8, 'y', 9);
            scanner.addTrans(10, 'e', 11);
            scanner.addTrans(11, 'r', 12);
            scanner.addTrans(12, 'i', 13);
            scanner.addTrans(13, 'v', 14);
            scanner.addTrans(13, 'm', 14);
            scanner.addTrans(14, 'e', 15);
            scanner.addTrans(16, 'l', 22);
            scanner.addTrans(16, 'f', 17);
            scanner.addTrans(18, 'l', 19);
            scanner.addTrans(18, 'n', 113);
            scanner.addTrans(19, 's', 20);
            scanner.addTrans(20, 'e', 21);
            scanner.addTrans(22, 'a', 23);
            scanner.addTrans(23, 'p', 24);
            scanner.addTrans(24, 'f', 38);
            scanner.addTrans(25, 'e', 33);
            scanner.addTrans(25, 'i', 26);
            scanner.addTrans(26, 'l', 27);
            scanner.addTrans(27, 'a', 28);
            scanner.addTrans(28, 'p', 29);
            scanner.addTrans(29, 'f', 39);
            scanner.addTrans(30, 'o', 31);
            scanner.addTrans(31, 'p', 32);
            scanner.addTrans(33, 'r', 34);
            scanner.addTrans(33, 'o', 89);
            scanner.addTrans(34, 'i', 35);
            scanner.addTrans(35, 'e', 36);
            scanner.addTrans(36, 's', 37);
            scanner.addTrans(40, 'o', 41);
            scanner.addTrans(41, 'n', 42);
            scanner.addTrans(42, 'e', 43);
            scanner.addTrans(44, 'o', 45);
            scanner.addTrans(45, 'g', 46);
            scanner.addTrans(46, 'i', 47);
            scanner.addTrans(47, 'c', 48);
            scanner.addTrans(48, 'a', 49);
            scanner.addTrans(49, 'l', 50);
            scanner.addTrans(51, 'e', 52);
            scanner.addTrans(52, 'r', 53);
            scanner.addTrans(53, 'm', 54);
            scanner.addTrans(54, 'i', 55);
            scanner.addTrans(55, 'n', 56);
            scanner.addTrans(56, 'a', 57);
            scanner.addTrans(57, 't', 58);
            scanner.addTrans(58, 'e', 59);
            scanner.addTrans(59, 't', 60);
            scanner.addTrans(60, 'h', 61);
            scanner.addTrans(61, 'i', 62);
            scanner.addTrans(62, 's', 63);
            scanner.addTrans(64, 'e', 81);
            scanner.addTrans(64, 'o', 65);
            scanner.addTrans(65, 't', 66);
            scanner.addTrans(66, 'a', 67);
            scanner.addTrans(67, 't', 68);
            scanner.addTrans(68, 'e', 69);
            scanner.addTrans(69, 'w', 77);
            scanner.addTrans(70, 'n', 71);
            scanner.addTrans(71, 't', 72);
            scanner.addTrans(72, 'i', 73);
            scanner.addTrans(73, 'n', 74);
            scanner.addTrans(74, 'u', 75);
            scanner.addTrans(75, 'e', 76);
            scanner.addTrans(76, 'w', 77);
            scanner.addTrans(77, 'h', 78);
            scanner.addTrans(78, 'e', 79);
            scanner.addTrans(79, 'n', 80);
            scanner.addTrans(81, 'p', 82);
            scanner.addTrans(82, 'l', 83);
            scanner.addTrans(83, 'y', 84);
            scanner.addTrans(84, 'w', 85);
            scanner.addTrans(85, 'i', 86);
            scanner.addTrans(86, 't', 87);
            scanner.addTrans(87, 'h', 88);
            scanner.addTrans(89, 'p', 90);
            scanner.addTrans(91, 'e', 92);
            scanner.addTrans(92, 'c', 93);
            scanner.addTrans(93, 'k', 94);
            scanner.addTrans(94, 's', 95);
            scanner.addTrans(95, 'i', 96);
            scanner.addTrans(96, 't', 97);
            scanner.addTrans(97, 'u', 98);
            scanner.addTrans(98, 'a', 99);
            scanner.addTrans(99, 't', 100);
            scanner.addTrans(100, 'i', 101);
            scanner.addTrans(101, 'o', 102);
            scanner.addTrans(102, 'n', 103);
            scanner.addTrans(103, 'o', 104);
            scanner.addTrans(104, 'f', 105);
            scanner.addTrans(106, 'r', 107);
            scanner.addTrans(107, 'o', 108);
            scanner.addTrans(108, 'g', 109);
            scanner.addTrans(109, 'r', 110);
            scanner.addTrans(110, 'a', 111);
            scanner.addTrans(111, 'm', 112);
            scanner.addTrans(113, 'd', 114);
            scanner.addTrans(116, '-', 145);
            scanner.addTrans(117, '>', 147);
            scanner.addTrans(119, '&', 120);
            scanner.addTrans(121, '|', 122);
            scanner.addTrans(124, '=', 125);
            scanner.addTrans(126, '*', 146);
            scanner.addTrans(126, '=', 127);
            scanner.addTrans(128, '=', 129);
            scanner.addTrans(130, '=', 131);
            scanner.addTrans(140, 's', 141);
            scanner.addTrans(141, 'i', 142);
            scanner.addTrans(142, 'n', 143);
            scanner.addTrans(143, 'g', 144);

            String str;
            var scan = "Inputs";
            Console.Write("Enter a string -->");
            int count = 1;
            while (!(str = Console.ReadLine()).Equals("\n"))
            {
                String[] strArr;
                strArr = str.Split(" ");
                for (int j = 0; j < strArr.Length; j++)
                {
                    if (scanner.recognize(strArr[j]))
                    {
                        Console.WriteLine("Line: " + count + "  Token Text: " + strArr[j] + "   Token Type: " + scanner.Words[strArr[j]]);
                    }
                    else
                    {
                        Console.WriteLine("The string \"" + str + "\" is rejected.");
                    }
                }
                count++;
                Console.Write("Enter a string -->");
            }
        }
        //public static void Main(string[] args)
        //{
        //    // TODO code application logic here
        //    var parser = new Parser("$Program Category");
        //    // i*i+(i+i)$
        //    parser.algorithm();


        //}

    }
}
